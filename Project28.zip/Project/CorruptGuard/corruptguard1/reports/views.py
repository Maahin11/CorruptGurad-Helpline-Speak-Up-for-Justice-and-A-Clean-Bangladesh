from django.shortcuts import render, redirect
from .forms import ReportForm
from django.contrib import messages

def submit_report(request):
    if request.method == 'POST':
        form = ReportForm(request.POST)
        if form.is_valid():
            # Save the report
            form.save()
            messages.success(request, 'Report submitted successfully!')
            return redirect('home')  # Redirect to home or a 'Thank You' page
    else:
        form = ReportForm()
    
    return render(request, 'reports/submit_report.html', {'form': form})
