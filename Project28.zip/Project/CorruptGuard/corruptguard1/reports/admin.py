from django.contrib import admin
from .models import Report

class ReportAdmin(admin.ModelAdmin):
    list_display = ('title', 'category', 'status', 'date_created', 'anonymous', 'submitted_by')
    list_filter = ('status', 'category', 'anonymous')
    search_fields = ('title', 'description')
    actions = ['mark_as_resolved', 'mark_as_reviewed', 'mark_as_pending']

    def mark_as_resolved(self, request, queryset):
        queryset.update(status='resolved')
    mark_as_resolved.short_description = "Mark selected reports as resolved"

    def mark_as_reviewed(self, request, queryset):
        queryset.update(status='reviewed')
    mark_as_reviewed.short_description = "Mark selected reports as reviewed"

    def mark_as_pending(self, request, queryset):
        queryset.update(status='pending')
    mark_as_pending.short_description = "Mark selected reports as pending"

admin.site.register(Report, ReportAdmin)
