from django.db import models
from django.contrib.auth.models import User

class Report(models.Model):
    # Category Choices
    CATEGORY_CHOICES = [
        ('bribery', 'Bribery'),
        ('embezzlement', 'Embezzlement'),
        ('fraud', 'Fraud'),
        ('nepotism', 'Nepotism'),
        ('other', 'Other'),
    ]

    # Report Status Choices
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('under_review', 'Under Review'),
        ('resolved', 'Resolved'),
    ]

    # Report Fields
    title = models.CharField(max_length=200)
    description = models.TextField()
    location = models.CharField(max_length=100)
    date_reported = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default='other')
    reported_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reports')

    def __str__(self):
        return self.title