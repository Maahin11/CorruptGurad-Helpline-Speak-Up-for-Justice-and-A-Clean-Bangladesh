from django.urls import path
from . import views

urlpatterns = [
    path('submit-report/', views.submit_report, name='submit_report'),
    path('public-awareness/', views.public_awareness, name='public_awareness'),
    path('', views.home, name='home'),
]
